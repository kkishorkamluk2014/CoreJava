package com.ecommerce.eapplication.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ecommerce.eapplication.dto.OrderDto;
import com.ecommerce.eapplication.model.Order;
import com.ecommerce.eapplication.model.Product;
import com.ecommerce.eapplication.repository.OrderRepository;
import com.ecommerce.eapplication.service.OrderService;

@Service
public class OrderServiceImpl implements OrderService {
	
	private static final Logger logger = LoggerFactory.getLogger(OrderServiceImpl.class);
	
	@Autowired
	OrderRepository orderRepository;
	
	@Override
	public String orderProduct(OrderDto orderdetails) {
		// TODO Auto-generated method stub
		Order order=new Order();
		LocalDateTime localDateTime = LocalDateTime.now();
		System.out.println("time:"+localDateTime);
		LocalDate localDate = localDateTime.toLocalDate();
		System.out.println("date:"+localDate);
		LocalTime localTime = localDateTime.toLocalTime();
		System.out.println("datetime:"+localTime);
		BeanUtils.copyProperties(orderdetails, order);
		System.out.println("After copying");
		try {
			System.out.println("Into try catch");
			order.setDate(java.sql.Date.valueOf(localDate));
			System.out.println("try1:"+java.sql.Date.valueOf(localDate));	
			order.setTime(java.sql.Time.valueOf(localTime));
			System.out.println("try2:"+java.sql.Time.valueOf(localTime));
			orderRepository.save(order);
			logger.info("Order saved successfully");
			return "Order saved successfully";
		}catch(Exception e) {
			logger.error("Order not saved");
			return "Order not saved successfully";
		}
	}

}
