package com.ecommerce.eapplication.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.eapplication.dto.OrderDto;
import com.ecommerce.eapplication.service.OrderService;


@RestController
@RequestMapping("/orders")
public class OrderController {
	
	@Autowired
	OrderService orderService;
	
	@PostMapping
	public ResponseEntity<?> orderProduct(@RequestBody OrderDto orderdetails) {
		String orderdto= orderService.orderProduct(orderdetails);
		if(orderdto!=null) {
			return new ResponseEntity<String>(orderdto,HttpStatus.CREATED );
		}else {
			return new ResponseEntity<String>("Ordering failed",HttpStatus.NOT_FOUND );		
		}
	}

}
