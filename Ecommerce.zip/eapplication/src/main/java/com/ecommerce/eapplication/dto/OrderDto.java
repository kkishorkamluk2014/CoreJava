package com.ecommerce.eapplication.dto;

import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;

import com.ecommerce.eapplication.model.OrderDetails;
import com.ecommerce.eapplication.model.Product;

public class OrderDto {
	
	Long orderid;
	Long userid;
	Long accountno;
	Double totalprice;
	//List<Product> productdetails= new ArrayList<>();
	List<OrderDetails> orderdetails;
	
	public List<OrderDetails> getOrderdetails() {
		return orderdetails;
	}
	public void setOrderdetails(List<OrderDetails> orderdetails) {
		this.orderdetails = orderdetails;
	}
	public Long getOrderid() {
		return orderid;
	}
	public void setOrderid(Long orderid) {
		this.orderid = orderid;
	}
	public Long getUserid() {
		return userid;
	}
	public void setUserid(Long userid) {
		this.userid = userid;
	}
	public Long getAccountno() {
		return accountno;
	}
	public void setAccountno(Long accountno) {
		this.accountno = accountno;
	}
	public Double getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(Double totalprice) {
		this.totalprice = totalprice;
	}

//	public List<Product> getProductdetails() {
//		return productdetails;
//	}
//	public void setProductdetails(List<Product> productdetails) {
//		this.productdetails = productdetails;
//	}

}
