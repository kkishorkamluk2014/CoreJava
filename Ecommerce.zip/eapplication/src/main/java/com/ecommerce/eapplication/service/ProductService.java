package com.ecommerce.eapplication.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ecommerce.eapplication.dto.ProductDto;
import com.ecommerce.eapplication.model.Product;

@Service
public interface ProductService {

	List<Product> searchProducts(String productname, String categoryname);
	
}
