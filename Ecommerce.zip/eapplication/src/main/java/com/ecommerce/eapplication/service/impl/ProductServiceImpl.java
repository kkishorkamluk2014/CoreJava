package com.ecommerce.eapplication.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.eapplication.dto.ProductDto;
import com.ecommerce.eapplication.model.Product;
import com.ecommerce.eapplication.repository.ProductRepository;
import com.ecommerce.eapplication.service.ProductService;
@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	ProductRepository productrepo;
	
	@Override
	public List<Product> searchProducts(String productname, String categoryname) {
		
		List<Product> productsdetails= new ArrayList<>();
		productsdetails=productrepo.findByProductnameContainsOrCategorynameContains(productname, categoryname);
		return productsdetails;
		
	}

}
