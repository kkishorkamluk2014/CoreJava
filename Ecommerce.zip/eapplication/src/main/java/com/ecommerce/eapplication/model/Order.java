package com.ecommerce.eapplication.model;

import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="ordertable")
public class Order {
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	Long orderid;
	@NotNull(message="User Id cannot be null")	
	Long userid;
	@NotNull(message="Account number cannot be null")	
	Long accountno;
	@NotNull(message="Total price cannot be null")	
	Double totalprice;
	Date date;
	Time time;
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name="orderid")
	List<OrderDetails> orderdetails;
	
	public Long getOrderid() {
		return orderid;
	}
	public void setOrderid(Long orderid) {
		this.orderid = orderid;
	}
	public Long getUserid() {
		return userid;
	}
	public void setUserid(Long userid) {
		this.userid = userid;
	}
	public Long getAccountno() {
		return accountno;
	}
	public void setAccountno(Long accountno) {
		this.accountno = accountno;
	}
	public Double getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(Double totalprice) {
		this.totalprice = totalprice;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Time getTime() {
		return time;
	}
	public void setTime(Time time) {
		this.time = time;
	}
	public List<OrderDetails> getOrderdetails() {
		return orderdetails;
	}
	public void setOrderdetails(List<OrderDetails> orderdetails) {
		this.orderdetails = orderdetails;
	}

	


}
