package com.ecommerce.eapplication.service;

import org.springframework.stereotype.Service;

import com.ecommerce.eapplication.dto.OrderDto;

@Service
public interface OrderService {

	String orderProduct(OrderDto orderDto );

}
