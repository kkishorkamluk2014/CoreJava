package com.ecommerce.eapplication.controller;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.eapplication.model.Product;
import com.ecommerce.eapplication.service.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {
	
	@Autowired
	ProductService productService;
	
	@GetMapping
	public ResponseEntity<?> searchProducts(@Valid @Pattern(regexp = "[a-z]")@RequestParam String productname,@Valid @Pattern(regexp = "[a-z]||[A-Z]") @RequestParam String categoryname) throws MethodArgumentNotValidException{
		List<Product> productDetails=new ArrayList<>();
		productDetails= productService.searchProducts(productname, categoryname);
		if(!productDetails.isEmpty()) {
			return new ResponseEntity<List<Product>>(productDetails, HttpStatus.OK);
		}
		return new ResponseEntity<String>("Product Not Found", HttpStatus.NOT_FOUND);

	}
	
//	@GetMapping
//	public List<Product> getProduct(@RequestParam String productname,String categoryname)
//	{
//		
//	}
	

}
