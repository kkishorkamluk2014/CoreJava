package com.ecommerce.eapplication.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="orderdetail")
public class OrderDetails {
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	Long orderdetailid;
	@OneToMany(cascade = CascadeType.ALL)
	List<Product> productdetails;
	public Long getOrderdetailid() {
		return orderdetailid;
	}
	public void setOrderdetailid(Long orderdetailid) {
		this.orderdetailid = orderdetailid;
	}
	public List<Product> getProductdetails() {
		return productdetails;
	}
	public void setProductdetails(List<Product> productdetails) {
		this.productdetails = productdetails;
	}



}
